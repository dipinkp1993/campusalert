<?php
$pc=mysqli_connect("localhost", "root", "", "campusalert");
?>